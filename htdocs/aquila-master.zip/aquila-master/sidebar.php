<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package Aquila
 */

?>

<aside id="secondary" role="complementary">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside><!-- #secondary -->
