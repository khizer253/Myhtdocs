import './clock';
import './carousel';
import './posts/loadmore';

// Styles
import '../sass/main.scss';

// Images.
import '../img/cats.jpg';
import '../img/patterns/cover.jpg';
