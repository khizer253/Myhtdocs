import '../sass/blocks.scss';

// Blocks
import './gutenberg/blocks/heading-with-icon';
import './gutenberg/blocks/dos-and-donts';
import './gutenberg/block-extensions/register-block-styles';
