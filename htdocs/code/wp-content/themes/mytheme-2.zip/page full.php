<?php
	/** Templatte name full width
	*/
	?>
	<?php get_header();?>
	
	<?php get_footer();?>