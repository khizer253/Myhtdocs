# to-do-list-PHP-MYSQL-
A to do list web app made from PHP and MYSQL.  Great User Inteface and Responsive Design
 Please modify the code and change your database name and tables name as according to your database.
  I havent made a setup for my program yet . But i will add this in future. Stay tuned.
