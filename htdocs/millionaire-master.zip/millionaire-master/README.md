millionaire
===========

Who wants to be a millionaire game

This is a simple game using php,jquery, and mysql loosely based on the Who Wants to Be A Millionaire.

#### How to

- Extract the files and put them in your web root.
- Take the out.sql file and import it into mysql.
- Change the database connection parameters in classes/question.php

